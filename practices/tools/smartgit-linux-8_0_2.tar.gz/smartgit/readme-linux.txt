Prerequisites
=============
You need to ensure that a Java Runtime Environment, version 1.7 or newer, is 
installed on your system.

Installation
============
SmartGit itself does not need to be installed; just unpack it to your preferred
location and launch the bin/smartgit.sh script. It might be necessary to tell
SmartGit where it can find your Java Runtime Environment. Create the file
~/.smartgit/smartgit.vmoptions and add following line (change the path)

jre=/path/to/your/jre

If you have further questions regarding the SmartGit on Linux, please ask in
our SmartGit mailing list:

http://www.syntevo.com/contact/
 
--
Your SmartGit-team
www.syntevo.com/smartgit
